using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using VoxIA.Services;

namespace VoxIA.UI
{
    public class FloatingHudOverlay : Form
    {
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WS_EX_TOPMOST = 0x00000008;
        private const int WS_EX_TOOLWINDOW = 0x00000080;

        private Label _lblIcon;
        private System.Windows.Forms.Timer _hideTimer;
        private Color _accentColor = Color.FromArgb(255, 90, 95);

        public FloatingHudOverlay()
        {
            InitializeComponent();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_NOACTIVATE | WS_EX_TOPMOST | WS_EX_TOOLWINDOW;
                return cp;
            }
        }

        private void InitializeComponent()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.StartPosition = FormStartPosition.Manual;
            this.Size = new Size(46, 46);
            this.BackColor = Color.FromArgb(20, 20, 24);
            this.DoubleBuffered = true;

            _lblIcon = new Label
            {
                Text = "🎙",
                Font = new Font("Segoe UI Emoji", 15F, FontStyle.Regular),
                ForeColor = Color.FromArgb(255, 90, 95),
                Location = new Point(0, 0),
                Size = new Size(46, 46),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };

            this.Controls.Add(_lblIcon);

            _hideTimer = new System.Windows.Forms.Timer();
            _hideTimer.Interval = 1600;
            _hideTimer.Tick += (s, e) =>
            {
                _hideTimer.Stop();
                this.Hide();
            };
        }

        public void ShowRecording()
        {
            if (!SettingsService.Current.ShowFloatingHud) return;

            this.InvokeIfRequired(() =>
            {
                _hideTimer.Stop();
                _lblIcon.Text = "🎙";
                _accentColor = Color.FromArgb(255, 90, 95);
                _lblIcon.ForeColor = _accentColor;
                PositionAtBottomRight();
                this.Show();
                this.BringToFront();
            });
        }

        public void ShowProcessing()
        {
            if (!SettingsService.Current.ShowFloatingHud) return;

            this.InvokeIfRequired(() =>
            {
                _hideTimer.Stop();
                _lblIcon.Text = "⏳";
                _accentColor = Color.FromArgb(255, 193, 7);
                _lblIcon.ForeColor = _accentColor;
                PositionAtBottomRight();
                this.Show();
                this.BringToFront();
            });
        }

        public void ShowSuccess()
        {
            if (!SettingsService.Current.ShowFloatingHud) return;

            this.InvokeIfRequired(() =>
            {
                _lblIcon.Text = "✓";
                _accentColor = Color.FromArgb(40, 167, 69);
                _lblIcon.ForeColor = _accentColor;
                PositionAtBottomRight();
                this.Show();
                this.BringToFront();
                _hideTimer.Start();
            });
        }

        public void ShowError(string msg)
        {
            if (!SettingsService.Current.ShowFloatingHud) return;

            this.InvokeIfRequired(() =>
            {
                _lblIcon.Text = "⚠";
                _accentColor = Color.FromArgb(220, 53, 69);
                _lblIcon.ForeColor = _accentColor;
                PositionAtBottomRight();
                this.Show();
                this.BringToFront();
                _hideTimer.Start();
            });
        }

        private void PositionAtBottomRight()
        {
            Rectangle workingArea = Screen.PrimaryScreen.WorkingArea;
            this.Location = new Point(workingArea.Right - 65, workingArea.Bottom - 65);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw sleek dark circular pill container with accent border
            using (SolidBrush bgBrush = new SolidBrush(Color.FromArgb(22, 22, 26)))
            {
                g.FillEllipse(bgBrush, 1, 1, 43, 43);
            }

            using (Pen borderPen = new Pen(Color.FromArgb(80, _accentColor.R, _accentColor.G, _accentColor.B), 2.0f))
            {
                g.DrawEllipse(borderPen, 1, 1, 43, 43);
            }
        }

        private void InvokeIfRequired(Action action)
        {
            if (this.InvokeRequired)
                this.Invoke(action);
            else
                action();
        }
    }
}
