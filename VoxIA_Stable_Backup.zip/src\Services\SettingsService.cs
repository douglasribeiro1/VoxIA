using System;
using System.IO;
using System.Web.Script.Serialization;

namespace VoxIA.Services
{
    public class AppSettings
    {
        public string WhisperModel { get; set; }
        public string CorrectionModel { get; set; }
        public string SelectedPromptPreset { get; set; }
        public string CustomPromptText { get; set; }
        public bool AutoCopyToClipboard { get; set; }
        public bool AutoStartWithWindows { get; set; }
        public bool AutoRetryOnReconnect { get; set; }
        public bool ShowFloatingHud { get; set; }
        public bool ShowNotifications { get; set; }
        public bool AudioBeepFeedback { get; set; }
        public bool PortableMode { get; set; }
        
        public string HotkeyDisplay { get; set; }
        public bool HotkeyUseCtrl { get; set; }
        public bool HotkeyUseWin { get; set; }
        public bool HotkeyUseAlt { get; set; }
        public bool HotkeyUseShift { get; set; }
        public int HotkeyVirtualKey { get; set; }

        public bool PushToTalkMode { get; set; }
        public bool SilenceAutoStop { get; set; }
        public int SilenceAutoStopSeconds { get; set; }

        public AppSettings()
        {
            WhisperModel = "whisper-large-v3-turbo";
            CorrectionModel = "openai/gpt-oss-120b";
            SelectedPromptPreset = "Geral / Ortografia";
            CustomPromptText = "";
            AutoCopyToClipboard = true;
            AutoStartWithWindows = false;
            AutoRetryOnReconnect = true;
            ShowFloatingHud = true;
            ShowNotifications = true;
            AudioBeepFeedback = true;
            PortableMode = false;

            HotkeyDisplay = "Ctrl + Win";
            HotkeyUseCtrl = true;
            HotkeyUseWin = true;
            HotkeyUseAlt = false;
            HotkeyUseShift = false;
            HotkeyVirtualKey = 0;

            PushToTalkMode = false;
            SilenceAutoStop = false;
            SilenceAutoStopSeconds = 3;
        }
    }

    public static class SettingsService
    {
        private static AppSettings _currentSettings;

        public static AppSettings Current
        {
            get
            {
                if (_currentSettings == null)
                    Load();
                return _currentSettings;
            }
        }

        public static void Load()
        {
            try
            {
                if (File.Exists(AppPathService.SettingsFilePath))
                {
                    string json = File.ReadAllText(AppPathService.SettingsFilePath);
                    var serializer = new JavaScriptSerializer();
                    _currentSettings = serializer.Deserialize<AppSettings>(json);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to load settings JSON. Using defaults.", ex);
            }

            if (_currentSettings == null)
            {
                _currentSettings = new AppSettings();
            }

            if (string.IsNullOrEmpty(_currentSettings.WhisperModel) || (_currentSettings.WhisperModel != "whisper-large-v3" && _currentSettings.WhisperModel != "whisper-large-v3-turbo"))
            {
                _currentSettings.WhisperModel = "whisper-large-v3-turbo";
            }

            if (string.IsNullOrEmpty(_currentSettings.CorrectionModel) || (_currentSettings.CorrectionModel != "openai/gpt-oss-120b" && _currentSettings.CorrectionModel != "qwen/qwen3.6-27b"))
            {
                _currentSettings.CorrectionModel = "openai/gpt-oss-120b";
            }

            if (_currentSettings.SelectedPromptPreset != "Customizado")
            {
                _currentSettings.SelectedPromptPreset = "Geral / Ortografia";
            }

            _currentSettings.PortableMode = AppPathService.IsPortableMode;
        }

        public static void Save()
        {
            try
            {
                if (_currentSettings == null) return;

                if (string.IsNullOrEmpty(_currentSettings.WhisperModel) || (_currentSettings.WhisperModel != "whisper-large-v3" && _currentSettings.WhisperModel != "whisper-large-v3-turbo"))
                {
                    _currentSettings.WhisperModel = "whisper-large-v3-turbo";
                }

                if (string.IsNullOrEmpty(_currentSettings.CorrectionModel) || (_currentSettings.CorrectionModel != "openai/gpt-oss-120b" && _currentSettings.CorrectionModel != "qwen/qwen3.6-27b"))
                {
                    _currentSettings.CorrectionModel = "openai/gpt-oss-120b";
                }

                if (_currentSettings.SelectedPromptPreset != "Customizado")
                {
                    _currentSettings.SelectedPromptPreset = "Geral / Ortografia";
                }

                var serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(_currentSettings);
                File.WriteAllText(AppPathService.SettingsFilePath, json);
                Logger.LogInfo("Settings saved successfully.");
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to save settings JSON", ex);
            }
        }
    }
}
