using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace VoxIA.Services
{
    public static class TextCorrectionService
    {
        private const string GroqChatEndpoint = "https://api.groq.com/openai/v1/chat/completions";

        public static async Task<string> CorrectTextAsync(string rawText, string modelOverride)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return string.Empty;

            string apiKey = SecureCredentialService.GetApiKey();
            if (string.IsNullOrEmpty(apiKey))
            {
                throw new InvalidOperationException("Groq API key is missing. Please configure your API key in Settings.");
            }

            string model = !string.IsNullOrEmpty(modelOverride) ? modelOverride : SettingsService.Current.CorrectionModel;
            if (string.IsNullOrEmpty(model) || (model != "openai/gpt-oss-120b" && model != "qwen/qwen3.6-27b"))
                model = "openai/gpt-oss-120b";

            string systemPrompt = GetSystemPrompt(SettingsService.Current.SelectedPromptPreset, SettingsService.Current.CustomPromptText);

            Logger.LogInfo(string.Format("Sending raw transcript ({0} chars) to Groq LLM ('{1}') for correction...", rawText.Length, model));

            using (var httpClient = new HttpClient())
            {
                httpClient.Timeout = TimeSpan.FromSeconds(60);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                var payload = new
                {
                    model = model,
                    temperature = 0.0,
                    max_tokens = 2048,
                    messages = new object[]
                    {
                        new { role = "system", content = systemPrompt },
                        new { role = "user", content = rawText }
                    }
                };

                var serializer = new JavaScriptSerializer();
                string jsonBody = serializer.Serialize(payload);
                var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await httpClient.PostAsync(GroqChatEndpoint, content);
                string responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    Logger.LogError(string.Format("Groq LLM API error (HTTP {0}): {1}", (int)response.StatusCode, responseBody));
                    throw new HttpRequestException(string.Format("Groq LLM API returned HTTP {0}: {1}", (int)response.StatusCode, responseBody));
                }

                var dict = serializer.Deserialize<Dictionary<string, object>>(responseBody);
                if (dict != null && dict.ContainsKey("choices"))
                {
                    var choices = dict["choices"] as System.Collections.ArrayList;
                    if (choices != null && choices.Count > 0)
                    {
                        var firstChoice = choices[0] as Dictionary<string, object>;
                        if (firstChoice != null && firstChoice.ContainsKey("message"))
                        {
                            var msg = firstChoice["message"] as Dictionary<string, object>;
                            if (msg != null && msg.ContainsKey("content"))
                            {
                                string corrected = msg["content"] != null ? msg["content"].ToString() : rawText;
                                corrected = CleanOutput(corrected);
                                Logger.LogInfo("Groq LLM text correction completed successfully.");
                                return corrected;
                            }
                        }
                    }
                }

                Logger.LogWarning("LLM response could not be parsed properly; using raw transcript.");
                return rawText;
            }
        }

        public static Task<string> CorrectTextAsync(string rawText)
        {
            return CorrectTextAsync(rawText, null);
        }

        private static string GetSystemPrompt(string preset, string customPrompt)
        {
            if (!string.IsNullOrWhiteSpace(customPrompt) && preset == "Customizado")
            {
                return customPrompt;
            }

            return @"Você é um aplicativo silencioso de ditado por voz e corretor ortográfico literal em português.
Sua ÚNICA E EXCLUSIVA TAREFA: Retornar a frase ditada pelo usuário com a ortografia, acentuação, capitalização e pontuação corrigidas.

REGRAS ABSOLUTAS E INVIOLÁVEIS:
1. NUNCA RESPONDA A PERGUNTAS! Se o usuário ditar uma pergunta (exemplo: 'O paciente tem febre?' ou 'Qual é o tratamento?'), NUNCA tente responder à pergunta. Sua função NÃO É conversar nem responder. Sua ÚNICA função é retornar a própria pergunta transcrita e corrigida ortograficamente (exemplo: 'O paciente tem febre?').
2. NUNCA REESCREVA A FRASE e NUNCA OMITA NENHUMA PALAVRA.
3. NUNCA substitua palavras por sinônimos nem altere o vocabulário.
4. NUNCA resuma, comente, dê conselhos ou adicione informações.
5. NÃO inclua explicações, introduções, aspas ou formatação Markdown.

RETORNE APENAS O TEXTO DITADO CORRIGIDO.";
        }

        private static string CleanOutput(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;
            string text = input.Trim();

            // Strip out <think>...</think> reasoning blocks from Qwen / DeepSeek models
            int thinkEnd = text.IndexOf("</think>", StringComparison.OrdinalIgnoreCase);
            if (thinkEnd >= 0)
            {
                text = text.Substring(thinkEnd + 8).Trim();
            }
            else if (text.StartsWith("<think>", StringComparison.OrdinalIgnoreCase))
            {
                int lastLineBreak = text.LastIndexOf("\n\n");
                if (lastLineBreak >= 0 && lastLineBreak + 2 < text.Length)
                {
                    text = text.Substring(lastLineBreak + 2).Trim();
                }
                else
                {
                    text = Regex.Replace(text, @"<think>[\s\S]*", "", RegexOptions.IgnoreCase).Trim();
                }
            }

            if (text.StartsWith("\"") && text.EndsWith("\"") && text.Length > 1)
            {
                text = text.Substring(1, text.Length - 2).Trim();
            }

            if (text.StartsWith("```") && text.EndsWith("```"))
            {
                int firstBreak = text.IndexOf('\n');
                if (firstBreak > 0 && text.Length > firstBreak + 3)
                {
                    text = text.Substring(firstBreak + 1, text.Length - firstBreak - 4).Trim();
                }
            }

            return text;
        }
    }
}
