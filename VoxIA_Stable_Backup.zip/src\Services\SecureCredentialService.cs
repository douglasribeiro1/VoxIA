using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace VoxIA.Services
{
    public static class SecureCredentialService
    {
        private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("VoxIA_Secure_Entropy_2026");

        public static void SaveApiKey(string apiKey)
        {
            if (string.IsNullOrEmpty(apiKey))
            {
                if (File.Exists(AppPathService.CredentialsFilePath))
                {
                    try { File.Delete(AppPathService.CredentialsFilePath); } catch { }
                }
                return;
            }

            try
            {
                byte[] raw = Encoding.UTF8.GetBytes(apiKey.Trim());
                byte[] encrypted = ProtectedData.Protect(raw, Entropy, DataProtectionScope.CurrentUser);
                File.WriteAllBytes(AppPathService.CredentialsFilePath, encrypted);
                Logger.LogInfo("Groq API key securely saved.");
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to encrypt and save Groq API key", ex);
            }
        }

        public static string GetApiKey()
        {
            if (!File.Exists(AppPathService.CredentialsFilePath))
                return string.Empty;

            try
            {
                byte[] encrypted = File.ReadAllBytes(AppPathService.CredentialsFilePath);
                byte[] raw = ProtectedData.Unprotect(encrypted, Entropy, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(raw);
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to decrypt Groq API key", ex);
                return string.Empty;
            }
        }
    }
}
