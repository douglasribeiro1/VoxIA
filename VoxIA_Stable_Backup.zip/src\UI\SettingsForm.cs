using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using VoxIA.Services;

namespace VoxIA.UI
{
    public class SettingsForm : Form
    {
        private TextBox _txtApiKey;
        private ComboBox _cboWhisperModel;
        private ComboBox _cboCorrectionModel;
        private ComboBox _cboPromptPreset;
        private TextBox _txtCustomPrompt;
        private CheckBox _chkAutoClipboard;
        private CheckBox _chkAutoStart;
        private CheckBox _chkPortableMode;
        private CheckBox _chkAudioBeep;
        private CheckBox _chkShowHud;
        private RadioButton _rdoToggleMode;
        private RadioButton _rdoPushToTalkMode;

        // Dictionary UI controls
        private ListView _lstDictionary;
        private TextBox _txtDictSearch;
        private Button _btnAddDict;
        private Button _btnEditDict;
        private Button _btnDeleteDict;
        private Button _btnClearDict;
        private Label _lblDictCount;

        private Button _btnSave;
        private Button _btnCancel;

        public SettingsForm()
        {
            InitializeComponent();
            LoadSettings();
            LoadDictionaryList();
        }

        private void InitializeComponent()
        {
            this.Text = "Configurações — VoxIA";
            this.Size = new Size(560, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.FromArgb(245, 246, 250);
            this.Font = new Font("Segoe UI", 9F, FontStyle.Regular);

            TabControl tabs = new TabControl
            {
                Location = new Point(12, 12),
                Size = new Size(520, 495)
            };

            // TAB 1: API & MODELOS
            TabPage tabApi = new TabPage("API & Modelos") { BackColor = Color.White };
            
            Label lblKey = new Label { Text = "Groq API Key:", Location = new Point(15, 12), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            _txtApiKey = new TextBox { Location = new Point(15, 32), Width = 475, UseSystemPasswordChar = true };
            Label lblKeyHint = new Label { Text = "Obtenha gratuitamente em console.groq.com", Location = new Point(15, 56), ForeColor = Color.Gray, AutoSize = true };

            // WHISPER MODEL SELECTOR
            Label lblWhisper = new Label { Text = "Modelo de Áudio / Transcrição (Whisper):", Location = new Point(15, 82), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            _cboWhisperModel = new ComboBox { Location = new Point(15, 102), Width = 475, DropDownStyle = ComboBoxStyle.DropDownList };
            _cboWhisperModel.Items.AddRange(new object[] {
                "whisper-large-v3-turbo (Whisper Large v3 Turbo — Padrão Recomendado)",
                "whisper-large-v3 (Whisper Large v3 — Alta Precisão)"
            });

            // TEXT LLM MODEL SELECTOR
            Label lblLLM = new Label { Text = "Modelo de Texto / Correção (LLM):", Location = new Point(15, 137), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            _cboCorrectionModel = new ComboBox { Location = new Point(15, 157), Width = 475, DropDownStyle = ComboBoxStyle.DropDownList };
            _cboCorrectionModel.Items.AddRange(new object[] {
                "openai/gpt-oss-120b (GPT OSS 120B — Padrão Recomendado / Máxima Qualidade)",
                "qwen/qwen3.6-27b (Qwen 3.6 27B — Alibaba / Corrigido)"
            });

            Label lblPreset = new Label { Text = "Modo de Correção de Texto:", Location = new Point(15, 192), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            _cboPromptPreset = new ComboBox { Location = new Point(15, 212), Width = 475, DropDownStyle = ComboBoxStyle.DropDownList };
            _cboPromptPreset.Items.AddRange(new object[] { "Geral / Ortografia", "Customizado" });
            _cboPromptPreset.SelectedIndexChanged += PromptPreset_Changed;

            Label lblCustomPrompt = new Label { Text = "Prompt Customizado (se selecionar Customizado):", Location = new Point(15, 247), AutoSize = true };
            _txtCustomPrompt = new TextBox { Location = new Point(15, 267), Width = 475, Height = 175, Multiline = true, ScrollBars = ScrollBars.Vertical, Enabled = false };

            tabApi.Controls.AddRange(new Control[] { 
                lblKey, _txtApiKey, lblKeyHint, 
                lblWhisper, _cboWhisperModel, 
                lblLLM, _cboCorrectionModel, 
                lblPreset, _cboPromptPreset, 
                lblCustomPrompt, _txtCustomPrompt 
            });

            // TAB 2: COMPORTAMENTO & GUIA DE ATALHOS
            TabPage tabBehavior = new TabPage("Comportamento & Atalhos") { BackColor = Color.White };

            // Panel with shortcuts reference
            Panel pnlShortcuts = new Panel
            {
                Location = new Point(15, 15),
                Size = new Size(475, 80),
                BackColor = Color.FromArgb(240, 244, 255),
                BorderStyle = BorderStyle.FixedSingle
            };
            Label lblShortcutsTitle = new Label
            {
                Text = "⌨ GUIA RÁPIDO DE ATALHOS GLOBAIS",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 102, 204),
                Location = new Point(10, 8),
                AutoSize = true
            };
            Label lblShortcutsInfo = new Label
            {
                Text = "• Ditado por Voz: Ctrl + Win (iniciar / parar)\n• Adicionar ao Dicionário: Ctrl + Shift + W (ou Ctrl + Shift + D)\n• Cancelar Ditado: Esc",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(33, 37, 41),
                Location = new Point(10, 28),
                AutoSize = true
            };
            pnlShortcuts.Controls.Add(lblShortcutsTitle);
            pnlShortcuts.Controls.Add(lblShortcutsInfo);

            _chkAutoClipboard = new CheckBox { Text = "Copiar automaticamente o texto final para a Área de Transferência (Clipboard)", Location = new Point(15, 105), Width = 475, AutoSize = true, Checked = true };
            _chkAutoStart = new CheckBox { Text = "Iniciar automaticamente com o Windows (residente na bandeja)", Location = new Point(15, 135), Width = 475, AutoSize = true };
            _chkPortableMode = new CheckBox { Text = "Modo Portátil (salvar dados no pen drive na pasta local ./data/)", Location = new Point(15, 165), Width = 475, AutoSize = true };
            _chkAudioBeep = new CheckBox { Text = "Sinal sonoro discreto ao iniciar e parar gravação (Beep feedback)", Location = new Point(15, 195), Width = 475, AutoSize = true, Checked = true };
            _chkShowHud = new CheckBox { Text = "Exibir indicador visual flutuante (HUD) durante a gravação/envio", Location = new Point(15, 225), Width = 475, AutoSize = true, Checked = true };

            GroupBox grpHotkey = new GroupBox { Text = "Modo de Acionamento do Atalho de Ditado (Ctrl + Win)", Location = new Point(15, 260), Size = new Size(475, 100) };
            _rdoToggleMode = new RadioButton { Text = "Pressionar 1x para Iniciar → Pressionar 1x para Parar (Padrão)", Location = new Point(15, 25), AutoSize = true, Checked = true };
            _rdoPushToTalkMode = new RadioButton { Text = "Manter pressionado para Falar → Soltar para Parar (Push-to-Talk)", Location = new Point(15, 55), AutoSize = true };
            grpHotkey.Controls.Add(_rdoToggleMode);
            grpHotkey.Controls.Add(_rdoPushToTalkMode);

            tabBehavior.Controls.AddRange(new Control[] { pnlShortcuts, _chkAutoClipboard, _chkAutoStart, _chkPortableMode, _chkAudioBeep, _chkShowHud, grpHotkey });

            // TAB 3: DICIONÁRIO DE PALAVRAS
            TabPage tabDict = new TabPage("📖 Dicionário de Palavras") { BackColor = Color.White };

            Panel pnlDictTip = new Panel
            {
                Location = new Point(15, 12),
                Size = new Size(475, 50),
                BackColor = Color.FromArgb(248, 249, 250),
                BorderStyle = BorderStyle.FixedSingle
            };
            Label lblDictTip = new Label
            {
                Text = "Dica: Selecione qualquer palavra em outro app e aperte Ctrl + Shift + W para cadastrar na hora!",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Italic),
                ForeColor = Color.FromArgb(73, 80, 87),
                Location = new Point(8, 15),
                AutoSize = true
            };
            pnlDictTip.Controls.Add(lblDictTip);

            Label lblSearch = new Label { Text = "🔍 Buscar:", Location = new Point(15, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            _txtDictSearch = new TextBox { Location = new Point(80, 67), Width = 260 };
            _txtDictSearch.TextChanged += (s, e) => FilterDictionaryList();

            _lblDictCount = new Label { Text = "0 palavras", Location = new Point(350, 70), AutoSize = true, ForeColor = Color.Gray };

            _lstDictionary = new ListView
            {
                Location = new Point(15, 95),
                Size = new Size(475, 305),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                Font = new Font("Segoe UI", 9F)
            };
            _lstDictionary.Columns.Add("De (Transcrito / Erro)", 175);
            _lstDictionary.Columns.Add("Para (Substituição Correta)", 185);
            _lstDictionary.Columns.Add("Tipo", 95);
            _lstDictionary.DoubleClick += (s, e) => EditSelectedDictionaryEntry();

            _btnAddDict = new Button { Text = "➕ Adicionar", Location = new Point(15, 410), Size = new Size(95, 30), BackColor = Color.FromArgb(0, 122, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            _btnAddDict.FlatAppearance.BorderSize = 0;
            _btnAddDict.Click += (s, e) => AddNewDictionaryEntry();

            _btnEditDict = new Button { Text = "✏ Editar", Location = new Point(115, 410), Size = new Size(80, 30) };
            _btnEditDict.Click += (s, e) => EditSelectedDictionaryEntry();

            _btnDeleteDict = new Button { Text = "🗑 Excluir", Location = new Point(200, 410), Size = new Size(80, 30) };
            _btnDeleteDict.Click += (s, e) => DeleteSelectedDictionaryEntry();

            _btnClearDict = new Button { Text = "Limpar Tudo", Location = new Point(390, 410), Size = new Size(100, 30), ForeColor = Color.DarkRed };
            _btnClearDict.Click += (s, e) => ClearAllDictionaryEntries();

            tabDict.Controls.AddRange(new Control[] {
                pnlDictTip, lblSearch, _txtDictSearch, _lblDictCount,
                _lstDictionary, _btnAddDict, _btnEditDict, _btnDeleteDict, _btnClearDict
            });

            tabs.TabPages.Add(tabApi);
            tabs.TabPages.Add(tabBehavior);
            tabs.TabPages.Add(tabDict);

            // FORM BUTTONS
            _btnSave = new Button { Text = "Salvar", Location = new Point(350, 518), Size = new Size(85, 32), DialogResult = DialogResult.OK, BackColor = Color.FromArgb(0, 122, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            _btnSave.FlatAppearance.BorderSize = 0;
            _btnSave.Click += BtnSave_Click;

            _btnCancel = new Button { Text = "Cancelar", Location = new Point(445, 518), Size = new Size(85, 32), DialogResult = DialogResult.Cancel };

            this.Controls.Add(tabs);
            this.Controls.Add(_btnSave);
            this.Controls.Add(_btnCancel);
            this.AcceptButton = _btnSave;
            this.CancelButton = _btnCancel;
        }

        private void PromptPreset_Changed(object sender, EventArgs e)
        {
            string sel = _cboPromptPreset.SelectedItem != null ? _cboPromptPreset.SelectedItem.ToString() : "";
            bool isCustom = (sel == "Customizado");
            _txtCustomPrompt.Enabled = isCustom;
        }

        private void LoadSettings()
        {
            var s = SettingsService.Current;
            _txtApiKey.Text = SecureCredentialService.GetApiKey();

            if (s.WhisperModel == "whisper-large-v3")
                _cboWhisperModel.SelectedIndex = 1;
            else
                _cboWhisperModel.SelectedIndex = 0;

            if (s.CorrectionModel == "qwen/qwen3.6-27b")
                _cboCorrectionModel.SelectedIndex = 1;
            else
                _cboCorrectionModel.SelectedIndex = 0;

            _cboPromptPreset.SelectedItem = s.SelectedPromptPreset;
            if (_cboPromptPreset.SelectedIndex < 0) _cboPromptPreset.SelectedIndex = 0;

            _txtCustomPrompt.Text = s.CustomPromptText;
            _chkAutoClipboard.Checked = s.AutoCopyToClipboard;
            _chkAutoStart.Checked = AutoStartService.IsAutoStartEnabled();
            _chkPortableMode.Checked = AppPathService.IsPortableMode;
            _chkAudioBeep.Checked = s.AudioBeepFeedback;
            _chkShowHud.Checked = s.ShowFloatingHud;

            if (s.PushToTalkMode)
                _rdoPushToTalkMode.Checked = true;
            else
                _rdoToggleMode.Checked = true;
        }

        private void LoadDictionaryList(string filter = null)
        {
            _lstDictionary.Items.Clear();
            var entries = DictionaryService.GetEntries();

            int count = 0;
            foreach (var entry in entries)
            {
                if (!string.IsNullOrEmpty(filter))
                {
                    bool match = (entry.Original != null && entry.Original.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
                              || (entry.Replacement != null && entry.Replacement.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0);
                    if (!match) continue;
                }

                var item = new ListViewItem(entry.Original ?? "");
                item.SubItems.Add(entry.Replacement ?? "");
                item.SubItems.Add(entry.IsVocabularyOnly ? "Vocabulário" : "Substituição");
                item.Tag = entry.Id;
                _lstDictionary.Items.Add(item);
                count++;
            }

            _lblDictCount.Text = string.Format("{0} palavra(s)", count);
        }

        private void FilterDictionaryList()
        {
            string filter = _txtDictSearch.Text.Trim();
            LoadDictionaryList(filter);
        }

        private void AddNewDictionaryEntry()
        {
            using (var form = new QuickDictionaryForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadDictionaryList(_txtDictSearch.Text.Trim());
                }
            }
        }

        private void EditSelectedDictionaryEntry()
        {
            if (_lstDictionary.SelectedItems.Count == 0) return;
            var item = _lstDictionary.SelectedItems[0];
            string orig = item.Text;
            string repl = item.SubItems.Count > 1 ? item.SubItems[1].Text : orig;

            using (var form = new QuickDictionaryForm(orig))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadDictionaryList(_txtDictSearch.Text.Trim());
                }
            }
        }

        private void DeleteSelectedDictionaryEntry()
        {
            if (_lstDictionary.SelectedItems.Count == 0) return;
            var item = _lstDictionary.SelectedItems[0];
            string id = item.Tag != null ? item.Tag.ToString() : null;

            if (!string.IsNullOrEmpty(id))
            {
                if (MessageBox.Show(string.Format("Deseja realmente remover a palavra \"{0}\" do dicionário?", item.Text), "Remover Termo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    DictionaryService.Remove(id);
                    LoadDictionaryList(_txtDictSearch.Text.Trim());
                }
            }
        }

        private void ClearAllDictionaryEntries()
        {
            if (MessageBox.Show("Tem certeza que deseja apagar TODAS as palavras e regras do dicionário?", "Limpar Dicionário", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                DictionaryService.Clear();
                LoadDictionaryList();
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            var s = SettingsService.Current;
            string apiKey = _txtApiKey.Text.Trim();
            SecureCredentialService.SaveApiKey(apiKey);

            if (_cboWhisperModel.SelectedIndex == 1)
                s.WhisperModel = "whisper-large-v3";
            else
                s.WhisperModel = "whisper-large-v3-turbo";

            if (_cboCorrectionModel.SelectedIndex == 1)
                s.CorrectionModel = "qwen/qwen3.6-27b";
            else
                s.CorrectionModel = "openai/gpt-oss-120b";

            s.SelectedPromptPreset = _cboPromptPreset.SelectedItem != null ? _cboPromptPreset.SelectedItem.ToString() : "Geral / Ortografia";
            s.CustomPromptText = _txtCustomPrompt.Text;
            s.AutoCopyToClipboard = _chkAutoClipboard.Checked;
            s.AudioBeepFeedback = _chkAudioBeep.Checked;
            s.ShowFloatingHud = _chkShowHud.Checked;
            s.PushToTalkMode = _rdoToggleMode.Checked == false;

            AutoStartService.SetAutoStart(_chkAutoStart.Checked);
            s.AutoStartWithWindows = _chkAutoStart.Checked;

            bool enablePortable = _chkPortableMode.Checked;
            AppPathService.EnablePortableMode(enablePortable);
            s.PortableMode = enablePortable;

            SettingsService.Save();
            this.Close();
        }
    }
}
